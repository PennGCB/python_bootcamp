#Class 8: Lecture and Problem Set
Our next class will be tomorrow in SCTR 12-146. We'll be learning some basics of plotting functions, flagged inputs, and an introduction to Raspberry Pi! After the lecture, we will have our annual mug ceremony!
 
Lecture
PPTX: lab8 slides
PDF (w/o notes): lab8 w/o notes (PDF)
PDF (w/ notes): lab8 with (a few) notes (PDF)
 
Download the following videos if you would like the embedded videos to work with the powerpoint presentation:
RaspberryPi First Task (LED Lights)
Raspberry Pi Snake Game
automatic curtain
 
Problem set
lab8 problem set
 
 
 
See you tomorrow!
Matt Paul
Sarah
 
