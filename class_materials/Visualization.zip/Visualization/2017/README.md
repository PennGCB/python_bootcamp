Hello all, Eli Piette here - I will be leading the lecture on visualization tomorrow in the John Morgan Building Wood Room. This room is pretty small and doesn't have a huge screen, so I apologize for the inconvenience. You'll probably want to have the slides up on your laptop during the talk to better follow along. See you soon!

 

Lecture:

 

Python_bootcamp_visualization_lecture_Piette_2017.pdf

 

Homework:

 

Visualization_lecture_HW.ipynb

 

 

Answers:

Visualization_lecture_HW_with_answers.ipynb


